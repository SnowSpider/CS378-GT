Nuclear W.A.R.(World Annihilation Requiescence)

Daniel Moreno drm2472 drmoreno
Wonjun Lee wl4337 wlee
Howard Fu hef79 howardfu

To build & run:

./buildit
./makeit
./OgreApp

