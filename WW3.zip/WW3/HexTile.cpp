#include "HexTile.h"

using namespace std;

void HexTile::setOwner(size_t him){
    owner = him;
}
